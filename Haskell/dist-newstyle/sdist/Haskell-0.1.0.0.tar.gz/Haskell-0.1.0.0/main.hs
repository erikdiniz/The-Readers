import Menu.MenuLogin


main :: IO()
main = do
    menuLogin