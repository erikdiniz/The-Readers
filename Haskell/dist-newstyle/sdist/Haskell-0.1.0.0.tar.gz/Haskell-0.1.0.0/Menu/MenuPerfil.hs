module Menu.MenuPerfil where

import Controller.Usuario
import Controller.Perfil
import Menu.MenuLogado
import Menu.MenuLogin


menuPerfil :: IO ()
menuPerfil = do
     putStrLn "Escolher opção: \n[V] Visão geral \n[E] Editar perfil\n[S] Voltar ao menu principal"
     opcao <- getLine
     selecionaAcao opcao


selecionaAcao :: String -> IO ()
selecionaAcao "V" = do
      exibirPerfil

selecionaAcao "E" = do
     putStrLn "Novo nome: "
     nome <- getLine

     putStrLn "Nova biografia: "
     biografi <- getLine
     perfil nome biografia

selecionaAcao "S" = do
     putStrLn "Obrigado!"

selecionaAcao "" = do
     putStrLn "Opção Inválida"
     menuPerfil

