
module Controller.Perfil where

import Data.Aeson
import Data.Aeson.Encode.Pretty (encodePretty)
import Data.Maybe
import GHC.Generics
import qualified Data.ByteString.Lazy as BS
import System.Directory
import System.IO.Unsafe

data Perfil = Perfil {
    nome :: String,
    biografia :: String,
    qtdSeguidores :: Int,
    qtdLivrosLidos :: Int
} deriving (Show, Generic)

instance ToJSON Perfil
instance FromJSON Perfil

criarPerfil ::  String->  String-> IO ()
cadastraPerfil nome biografia = do
    let novoPerfil = Perfil nome biografia [] []
    adicionaPerfil (fromJust maybeJson) novoPerfil


{-Escreve na lista inteira de usuarios um usuario novo-}
adicionaPerfil :: [Perfil] -> Perfil -> IO()
adicionaPerfil perfis perfil = do
    let novosPerfis  = encodePretty (perfil : perfis)
    BS.writeFile "Data/temp.json" novosPerfis
    removeFile "Data/usuarios.json"
    renameFile "Data/temp.json" "Data/usuarios.json"

exibirPerfil :: IO()
exibirPerfil = do
  putStrLn $ ".---------------------------------------------." ++ "\n"
              ++ "|            PERFIL DE USUÁRIO                |" ++ "\n"
              ++ ".---------------------------------------------." ++ "\n"
  putStrLn $ "Nome: " ++ nome
  putStrLn $ "Biografia: " ++ biografia